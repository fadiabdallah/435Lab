import java.util.ArrayList;
import java.util.List;


public class variables {
	
	static String User="mhmd";
    static int BOARD_WIDTH = 358;
    static int BOARD_HEIGHT = 350;
    static int BORDER_RIGHT = 30;
    static int BORDER_LEFT = 5;
    static int playerindex=0;
   static List<Integer>playerScore= new ArrayList<>();
    static int GROUND = 290;
    static int BOMB_HEIGHT = 5;

    static int ALIEN_HEIGHT = 12;
    static int ALIEN_WIDTH = 12;
    static int ALIEN_INIT_X = 150;
    static int ALIEN_INIT_Y = 5;

    static int GO_DOWN = 15;
    public static int NUMBER_OF_ALIENS_TO_DESTROY = 30;
    static int CHANCE = 55;
    public static int DELAY = 10;
    static int PLAYER_WIDTH = 15;
    static int PLAYER_HEIGHT = 10;
    static int alienTimer=0;
}
